"use client";
import {useState} from "react";
import {Search, ShoppingBag, Menu, ArrowRight} from "lucide-react";
const products=[{name:"Phone Pro",tag:"Titanium. Powerful. Personal.",price:"From $999",tone:"from-zinc-900 to-zinc-600"},{name:"Tablet Air",tag:"Light. Fast. Brilliant.",price:"From $599",tone:"from-sky-200 to-indigo-300"},{name:"Laptop Pro",tag:"Pro power. Anywhere.",price:"From $1,299",tone:"from-slate-700 to-slate-950"}];
export default function Home(){const [menu,setMenu]=useState(false);return <main><nav className="glass sticky top-0 z-50 border-b border-black/10"><div className="mx-auto flex h-12 max-w-6xl items-center justify-between px-5"><button aria-label="Menu" onClick={()=>setMenu(!menu)} className="md:hidden"><Menu size={20}/></button><div className="font-bold text-xl">◉</div><div className="hidden gap-7 text-xs md:flex"><a href="#store">Store</a><a href="#products">Products</a><a href="#support">Support</a><a href="#nvidia">NVIDIA</a><a href="#about">About</a></div><div className="flex gap-4"><Search size={18}/><ShoppingBag size={18}/></div></div>{menu&&<div className="border-t p-5 md:hidden"><a className="block py-2" href="#store">Store</a><a className="block py-2" href="#products">Products</a><a className="block py-2" href="#support">Support</a><a className="block py-2" href="#nvidia">NVIDIA</a></div>}</nav><section id="store" className="px-5 pt-16 text-center"><p className="mb-3 text-sm font-semibold">New arrivals</p><h1 className="text-5xl font-bold tracking-tight md:text-7xl">Designed to delight.</h1><p className="mx-auto mt-5 max-w-2xl text-lg text-zinc-600">A clean, modern storefront foundation built with Next.js, TypeScript, Tailwind CSS, and Vercel.</p><div className="mt-7 flex justify-center gap-6 text-sm"><a className="font-medium text-blue-600" href="#products">Shop products <ArrowRight className="ml-1 inline" size={14}/></a><a className="font-medium text-blue-600" href="#about">Learn more <ArrowRight className="ml-1 inline" size={14}/></a></div><div className="mx-auto mt-14 h-80 max-w-5xl rounded-[2rem] bg-gradient-to-br from-white to-zinc-200 shadow-2xl"/></section><section id="products" className="mx-auto max-w-6xl px-5 py-24"><h2 className="mb-8 text-3xl font-bold">Explore the lineup.</h2><div className="grid gap-6 md:grid-cols-3">{products.map(p=><article key={p.name} className="overflow-hidden rounded-3xl bg-white shadow-sm"><div className={`h-72 bg-gradient-to-br ${p.tone} p-7 text-white`}><span className="text-sm font-medium opacity-80">{p.name}</span><div className="mt-40 text-2xl font-bold">{p.tag}</div></div><div className="p-7"><p className="text-sm text-zinc-500">{p.price}</p><button className="mt-5 rounded-full bg-black px-5 py-2 text-sm font-medium text-white">Buy</button></div></article>)}</div></section><section id="nvidia" className="bg-zinc-950 px-5 py-24 text-white">
<div className="mx-auto max-w-6xl">
<div className="grid gap-12 md:grid-cols-2 md:items-center">
<div>
<p className="text-sm font-semibold text-zinc-400">NVIDIA</p>
<h2 className="mt-3 text-4xl font-bold tracking-tight md:text-5xl">Accelerated computing for the AI era.</h2>
<p className="mt-5 max-w-xl text-lg leading-8 text-zinc-300">Explore NVIDIA technology across AI infrastructure, accelerated computing, robotics, networking, and RTX graphics.</p>
<div className="mt-7 flex flex-wrap gap-4">
<a className="rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-black" href="https://www.nvidia.com/" target="_blank" rel="noreferrer">Visit NVIDIA</a>
<a className="rounded-full border border-white/20 px-5 py-2.5 text-sm font-medium text-white" href="https://www.linkedin.com/company/nvidia/" target="_blank" rel="noreferrer">NVIDIA on LinkedIn</a>
</div>
</div>
<div className="rounded-[2rem] border border-white/10 bg-gradient-to-br from-zinc-800 to-black p-8 shadow-2xl">
<div className="grid grid-cols-2 gap-4 text-sm">
<div className="rounded-2xl bg-white/5 p-5"><p className="font-semibold">AI Infrastructure</p><p className="mt-2 text-zinc-400">Accelerated data-center computing.</p></div>
<div className="rounded-2xl bg-white/5 p-5"><p className="font-semibold">RTX Graphics</p><p className="mt-2 text-zinc-400">Real-time graphics and AI.</p></div>
<div className="rounded-2xl bg-white/5 p-5"><p className="font-semibold">Robotics</p><p className="mt-2 text-zinc-400">Physical AI and simulation.</p></div>
<div className="rounded-2xl bg-white/5 p-5"><p className="font-semibold">Networking</p><p className="mt-2 text-zinc-400">High-performance AI connectivity.</p></div>
</div>
</div>
</div>
</div>
</section><section id="support" className="bg-white px-5 py-24 text-center"><h2 className="text-4xl font-bold">Need help?</h2><p className="mt-4 text-zinc-600">Support, ordering, NVIDIA resources, and account flows can be added next.</p></section><footer id="about" className="mx-auto max-w-6xl px-5 py-10 text-xs text-zinc-500">Independent storefront demo. Not affiliated with or operated by Apple.</footer></main>}
